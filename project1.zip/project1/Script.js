// Get all the necessary DOM elements
const temp = document.getElementById('temp');
const date = document.getElementById('date-time');
const currentLocation = document.getElementById('locations');
const condition = document.getElementById('condition');
const rain = document.getElementById('rain');
const uvIndex = document.querySelector('.uv-index');
const uvText = document.querySelector('.uv-text');
const windSpeed = document.querySelector('.wind-speed');
const sunRise = document.querySelector('.sunrise');
const sunSet = document.querySelector('.sunset');
const humidity = document.querySelector('.humidity');
const visibility = document.querySelector('.visibility');
const humidityStatus = document.querySelector('.humidity-status');
const airQuality = document.querySelector('.air-quality');
const airQualityStatus = document.querySelector('.air-quality-status');
const visibilityStatus = document.querySelector('.visibility-status');

let currentCity = "";
let currentUnit = "f";
let hourlyOrWeek = "Week";

// Function to get current date and time
function getDateTime() {
    let now = new Date(),
        hour = now.getHours(),
        minute = now.getMinutes();

    let days = [
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    ];

    let period = hour >= 12 ? 'PM' : 'AM';
    hour = hour % 12;
    hour = hour ? hour : 12; // hour 0 should be 12

    if (minute < 10) {
        minute = '0' + minute;
    }

    let dayString = days[now.getDay()];
    return `${dayString}, ${hour}:${minute} ${period}`;
}

// Update date and time every second
date.innerText = getDateTime();
setInterval(() => {
    date.innerText = getDateTime();
}, 1000);

// Function to get public IP and location
function getPublicIp() {
    fetch("https://geolocation-db.com/json/", {
        method: "GET"
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
        currentCity = data.city;
        getWeatherData(data.city, currentUnit, hourlyOrWeek);
    })
    .catch(error => console.error('Error:', error));
}

getPublicIp();

// Function to get weather data
function getWeatherData(city, unit, hourlyOrWeek) {
    const apiKey = 'YOUR_VISUAL_CROSSING_API_KEY'; // Replace with your API key
    fetch(`https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${city}?unitGroup=metric&key=${apiKey}&contentType=json`, {
        method: 'GET'
    })
    .then(response => response.json())
    .then(data => {
        let today = data.currentConditions;
        if (unit === "c") {
            temp.innerText = today.temp;
        } else {
            temp.innerText = celsiusToFahrenheit(today.temp);
        }
        currentLocation.innerText = data.resolvedAddress;
        condition.innerText = today.conditions;
        rain.innerHTML = `${today.precip}% <svg xmlns="http://www.w3.org/2000/svg" width="36" height="20" fill="currentColor" class="bi bi-droplet-fill" viewBox="0 0 16 16"><path d="M8 16a6 6 0 0 0 6-6c0-1.655-1.122-2.904-2.432-4.362C10.254 4.176 8.75 2.503 8 0c0 0-6 5.686-6 10a6 6 0 0 0 6 6M6.646 4.646l.708.708c-.29.29-1.128 1.311-1.907 2.87l-.894-.448c.82-1.641 1.717-2.753 2.093-3.13"/></svg>`;
        uvIndex.innerText = today.uvindex;
        uvText.innerText = getUVIndexText(today.uvindex);
        windSpeed.innerText = `${today.windspeed} km/h`;
        sunRise.innerText = today.sunrise;
        sunSet.innerText = today.sunset;
        humidity.innerText = `${today.humidity}%`;
        visibility.innerText = `${today.visibility} km`;
        humidityStatus.innerText = getHumidityStatus(today.humidity);
        airQuality.innerText = today.airquality;
        airQualityStatus.innerText = getAirQualityStatus(today.airquality);
        visibilityStatus.innerText = getVisibilityStatus(today.visibility);
    })
    .catch(error => console.error('Error:', error));
}

// Helper functions
function celsiusToFahrenheit(temp) {
    return ((temp * 9) / 5 + 32).toFixed(1);
}

function getUVIndexText(index) {
    if (index < 3) return "Low";
    if (index < 6) return "Moderate";
    if (index < 8) return "High";
    if (index < 11) return "Very High";
    return "Extreme";
}

function getHumidityStatus(humidity) {
    if (humidity < 30) return "Low";
    if (humidity < 60) return "Comfortable";
    return "High";
}

function getAirQualityStatus(aqi) {
    if (aqi <= 50) return "Good";
    if (aqi <= 100) return "Moderate";
    if (aqi <= 150) return "Unhealthy for Sensitive Groups";
    if (aqi <= 200) return "Unhealthy";
    if (aqi <= 300) return "Very Unhealthy";
    return "Hazardous";
}

function getVisibilityStatus(visibility) {
    if (visibility > 10) return "Excellent";
    if (visibility > 5) return "Good";
    if (visibility > 1) return "Moderate";
    return "Poor";
}
